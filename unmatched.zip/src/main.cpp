#include <cstdlib>
#include <ctime>
#include "Controller.hpp"

int main()
{
    srand(static_cast<unsigned int>(time(0)));

    Controller controller;

    controller.startMenu();
    controller.playTurn();

  	return 0;
}